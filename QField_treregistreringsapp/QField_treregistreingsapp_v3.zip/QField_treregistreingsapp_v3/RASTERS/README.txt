Add your Canopy Height Model raster here. 
