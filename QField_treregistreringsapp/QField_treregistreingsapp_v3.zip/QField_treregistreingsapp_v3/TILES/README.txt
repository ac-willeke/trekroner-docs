In case you want to use your app without mobile data, you can generate MBTILES and add them here. 
An example tile for Sandvika is added. 
